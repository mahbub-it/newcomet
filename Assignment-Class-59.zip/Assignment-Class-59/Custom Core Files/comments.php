
<?php
/**
 * The template for displaying Comments.
 *
 * The area of the page that contains comments and the comment form.
 * @subpackage newcomet
 * @since newcomet 1.0
 */

/*
 * If the current post is protected by a password and the visitor has not yet
 * entered the password we will return early without loading the comments.
 */

 if( post_password_required() ){
	return;
}

?>

<div id="comments">

    <?php 
        if( have_comments() ):
        //We have comments
      ?>
      
      <h5 class="upper">
        <?php
          
          printf(
            esc_html( _nx( 'One comment on &ldquo;%2$s&rdquo;', '%1$s comments on &ldquo;%2$s&rdquo;', get_comments_number(), 'comments title', 'newcomet' ) ),
            number_format_i18n( get_comments_number() ),
            '<span>' . get_the_title() . '</span>'
          );
        
        ?>
    </h5>


      <ul class="comment-list">

          <?php 

                $args = array(
                  'walker'			      => null,
                  'max_depth' 		    => '',
                  'style'				      => 'ul',
                  'callback'			    => 'better_commets',
                  'end-callback'		  => null,
                  'type'				      => 'comment',
                  'reply_text'		    => 'Reply',
                  'page'				      => '',
                  'per_page'			    => '',
                  'avatar_size'		    => 75,
                  'reverse_top_level' => null,
                  'reverse_children'	=> null,
                  'format'			      => 'html5',
                  'short_ping'		    => true,
                  'echo'				      => true,
                  
                );

                wp_list_comments( $args );
            ?>

        </ul></div>



    <?php 
      if( !comments_open() && get_comments_number() ):
    ?>

    <p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'newcomet' ); ?> </p>

    <?php 
      endif;
    ?>  

    <?php 
      endif;
    ?>
    
  <?php
function prefix_move_comment_field_to_bottom( $fields ) {

	$comment_field = $fields['comment'];
	unset( $fields['comment'] );
	$fields['comment'] = $comment_field;
	return $fields;

}

add_filter( 'comment_form_fields', 'custom_comment_field' );
    function custom_comment_field( $fields ) {

      unset($fields['cookies']);
      unset($fields['url']);

      return $fields;
}

add_filter( 'comment_form_defaults', 'custom_reply_title' );
function custom_reply_title( $defaults ){
  $defaults['title_reply_before'] = '<h5 id="reply-title" class="h4 comment-reply-title">';
  $defaults['title_reply_after'] = '</h5>';
  return $defaults;
}

add_filter( 'comment_form_fields', 'prefix_move_comment_field_to_bottom', 10, 1 );
      $fields = array(

        'author' => 
        '<div class="form-double"><div class="form-group"><input id="author" name="author" type="text" placeholder="Name" class="form-control" value="' . esc_attr( $commenter['comment_author'] ) . '" required="required" /></div>',
        	
        'email' =>
        '<div class="form-group last"><input id="email" name="email" class="form-control" type="text" placeholder="Email" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" required="required" /></div></div>',
        
        // 'url' =>
        // '<div class="form-group last-field"><label for="url">' . __( 'Website', 'domainreference' ) . '</label><input id="url" name="url" class="form-control" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) . '" /></div>'
      
      );
  
      $args = array(
        'title_reply' => __( 'LEAVE A COMMENT' ),
        'class_submit' => 'btn btn-color-out', //Button Css
        'label_submit' => __('Post Commment'),
        'comment_field' =>
				'<div class="form-group text-right"><textarea id="comment" class="form-control" placeholder="Comment" name="comment" rows="4" required="required"></textarea></p>',
			'fields' => apply_filters( 'comment_form_default_fields', $fields )
      );

      comment_form( $args ); 
      
      
  ?>


</div><!--.comments-area -->



