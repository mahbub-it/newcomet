<?php

/**
 * Theme Support Option.
 *
 * The area of the page that contains comments and the comment form.
 * @subpackage newcomet
 * 
 */


/* Activate HTML5 features */
add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );

