<?php
if( ! function_exists( 'better_commets' ) ):
function better_commets($comment, $args, $depth) {
    ?>
   <li id="li-comment-<?php comment_ID() ?>">
    <div class="comment">
        <div class="comment-pic">
            <?php echo get_avatar($comment,$size='75',$default='http://0.gravatar.com/avatar/36c2a25e62935705c5565ec465c59a70?s=32&d=mm&r=g' ); ?> 
        </div>
        <div class="comment-text">
            <h5 class="upper"><?php echo get_comment_author() ?></h5>
            <span class="comment-date"><?php printf(/* translators: 1: date and time(s). */ esc_html__('%1$s at %2$s' , '5balloons_theme'), get_comment_date(),  get_comment_time()) ?></span>
                <?php comment_text() ?>

                <span href="#" class="comment-reply"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?></span>

            
                <?php if ($comment->comment_approved == '0') : ?>
                    <em><?php esc_html_e('Your comment is awaiting moderation.','newcomet') ?></em>
                    <br />
                <?php endif; ?>
                
           
        </div>
        </div>

<?php
        }
endif;