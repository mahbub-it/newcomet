<?php 

/**
 * newcomet 2023 functions and definitions
 *
 * This is a custom theme for all user can customize
 *
 * I using this theme for practice
 */


add_action('after_setup_theme', 'newcomet_functions');

function newcomet_functions(){

	// Theme Text Domain
	load_theme_textdomain('newcomet', get_template_directory().'/lang');

	// Adding theme supports
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');

	// Enable support for Post Formats.
    add_theme_support(
	   'post-formats',
	   array(
		   'video',
		   'quote',
		   'gallery',
		   'audio',
	   ));

	   register_nav_menu('main-menu', 'NewComet Menu');

	   // Slider
	   register_post_type('newcomet-slider', array(
		   'labels'					=> array(
			   'name'				=> 'NewComet Sliders',
			   'add_new'			=> 'Add New Slider',
			   'add_new_item'		=> 'Add New Sliders'
		   ),
		   'public'	=> true,
		   'supports'	=> array('title', 'editor', 'thumbnail') 
	   ));

	   
	// Portfolio
	register_post_type('newcomet-portfolio', array(
		'labels'			=> array(
			'name'			=> __('Portfolio', 'newcomet'),
			'add_new' 		=> __('Add New Portfolio', 'newcomet'),
			'add_new_item' 	=> __('Add New Portfolio', 'newcomet'),
		),
		'public'	=> true,
		'supports'	=> array('title', 'editor', 'thumbnail')
	));

	// SELECTED WORKS Section
	register_taxonomy('newcomet-portfolio-category', 'newcomet-portfolio', array(
		'labels'			=> array(
			'name'			=> 'Portfolio Type',
			'add_new' 		=> 'Add New Type',
			'add_new_item' 	=> 'Add New Type',
		),
		'public' 			=> true,
		'hierarchical'		=> true //Category Type
	));




}

// For Default call back menu
function default_main_menu(){
	?>
	 <div id="navigation">
		<ul class="navigation-menu">
			<li class="active">
				<a href="#">Home</a>
			</li>
		</ul>
	</div>
	  <?php
	}
	
// Adding fonts
function get_newcomet_fonts(){

	$fonts	= array();

	$fonts[] = 'Montserrat:400,700';

	$fonts[] = 'Raleway:300,400,500';

	$fonts[] = 'Halant:300,400';

	$newcomet_fonts = add_query_arg(array(
		'family'	=> urlencode( implode( '|', $fonts) ),
		'subset'	=> 'latin',
	), 'https://fonts.googleapis.com/css');

	return $newcomet_fonts;
}

// Including the theme styles
add_action('wp_enqueue_scripts', 'newcomet_styles');

function newcomet_styles(){

	wp_enqueue_style('bundle', get_template_directory_uri().'/css/bundle.css');

	wp_enqueue_style('main', get_template_directory_uri().'/css/style.css');

	wp_enqueue_style('fonts', get_newcomet_fonts());

	wp_enqueue_style('stylesheet', get_stylesheet_uri());

	wp_enqueue_style('comment-reply');

}

add_action('wp_enqueue_scripts', 'newcomet_conditional_scripts');

function newcomet_conditional_scripts(){
	wp_enqueue_script('html5shim', 'http://html5shim.googlecode.com/svn/trunk/html5.js', array(), '', false);
	wp_script_add_data('html5shim', 'conditional', 'lt IE 9');

	wp_enqueue_script('respond', 'https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js', array(), '', false);
	wp_script_add_data('respond', 'conditional', 'lt IE 9');

	wp_enqueue_script('comment-reply');
}


// Register Sidebar
add_action('widgets_init', 'sidebar_section');

function sidebar_section(){
	register_sidebar($args = array(
		'name'			=> __('Right Sidebar', 'newcomet'),
		'description'	=> __('Create a Right sideber', 'newcomet'),
		'id'			=> 'right-sidebar',
		'before_widget' => '<div class="widget">',
		'after_widget'	=> '</div>',
		'before_title'	=> '<h6 class="upper">',
		'after_title'	=> '</h6>'


	));

	register_sidebar($args = array(
		'name'			=> __('Footer First Area', 'newcomet'),
		'description'	=> __('Create a Footer First Area', 'newcomet'),
		'id'			=> 'footer-first',
		'before_widget' => '<div class="col-sm-4"><div class="widget">',
		'after_widget'	=> '</div></div>',
		'before_title'	=> '<h6 class="upper">',
		'after_title'	=> '</h6>'

	));

	register_sidebar($args = array(
		'name'			=> __('Footer Last Area', 'newcomet'),
		'description'	=> __('Create a Footer Last Area', 'newcomet'),
		'id'			=> 'footer-last',
		'before_widget' => '<div class="widget">',
		'after_widget'	=> '</div>',
		'before_title'	=> '<h6 class="upper">',
		'after_title'	=> '</h6>'

	));

}

add_action('wp_enqueue_scripts', 'newcomet_scripts');

function newcomet_scripts(){
	wp_enqueue_script('jQuery', get_template_directory_uri() . '/js/jquery.js');
	wp_enqueue_script('bundle', get_template_directory_uri() . '/js/bundle.js', array('jQuery'), '', true);
	wp_enqueue_script('google-map', 'https://maps.googleapis.com/maps/api/js?v=3.exp', array('jQuery'), '', true);
	wp_enqueue_script('main', get_template_directory_uri() . '/js/main.js', array('jQuery', 'bundle'), '', true);
}

add_action('admin_print_scripts', 'new_script_adding', 1000);

function new_script_adding(){ ?>

	<?php if(get_post_type() == 'post') : ?>

	<script>
		
		jQuery(document).ready(function(){

			var id = jQuery('input[name="post_format"]:checked').attr('id');

			if(id == 'post-format-video'){
				jQuery('.cmb2-id--for-video').show();
			}else{
				jQuery('.cmb2-id--for-video').hide();
			}

			if(id == 'post-format-gallery'){
				jQuery('.cmb2-id--for-gallery').show();
			}else{
				jQuery('.cmb2-id--for-gallery').hide();
			}

			if(id == 'post-format-audio'){
				jQuery('.cmb2-id--for-audio').show();
			}else{
				jQuery('.cmb2-id--for-audio').hide();
			}

			jQuery('input[name="post_format"]').change(function(){
				jQuery('.cmb2-id--for-video').hide();
				jQuery('.cmb2-id--for-gallery').hide();
				jQuery('.cmb2-id--for-audio').hide();

				var id = jQuery('input[name="post_format"]:checked').attr('id');

			if(id == 'post-format-video'){
				jQuery('.cmb2-id--for-video').show();
			}else{
				jQuery('.cmb2-id--for-video').hide();
			}

			if(id == 'post-format-gallery'){
				jQuery('.cmb2-id--for-gallery').show();
			}else{
				jQuery('.cmb2-id--for-gallery').hide();
			}

			if(id == 'post-format-audio'){
				jQuery('.cmb2-id--for-audio').show();
			}else{
				jQuery('.cmb2-id--for-audio').hide();
			}


			});
		})
	</script>

	<?php endif; ?>
	
	<?php }

// Files including
if(file_exists( dirname( __FILE__ ) .'/gallery.php' ) ){

	require_once( dirname( __FILE__ ) .'/gallery.php' );	
}

if(file_exists( dirname( __FILE__ ) .'/custom-widgets/latest-post.php' ) ){

	require_once( dirname( __FILE__ ) .'/custom-widgets/latest-post.php' );
}

// Redux Framework including
if(file_exists( dirname( __FILE__ ) .'/lib/redux-core/framework.php' ) ){

	require_once( dirname( __FILE__ ) .'/lib/redux-core/framework.php' );
}

if(file_exists( dirname( __FILE__ ) .'/lib/sample/config.php' ) ){

	require_once( dirname( __FILE__ ) .'/lib/sample/config.php' );	
}

// CM2 Metabox including
if(file_exists( dirname( __FILE__ ) .'/lib/metabox/init.php' ) ){

	require_once( dirname( __FILE__ ) .'/lib/metabox/init.php' );	
}

if(file_exists( dirname( __FILE__ ) .'/lib/metabox/config.php' ) ){

	require_once( dirname( __FILE__ ) .'/lib/metabox/config.php' );	
}

if(file_exists( dirname( __FILE__ ) .'/newcomet-nav-walker.php' ) ){

	require_once( dirname( __FILE__ ) .'/newcomet-nav-walker.php' );	
}

// if(file_exists( dirname( __FILE__ ) .'/classes/class.newcomet-walker.php' ) ){

// 	require_once( dirname( __FILE__ ) .'/classes/class.newcomet-walker.php' );	
// }

if(file_exists( dirname( __FILE__ ) .'/shortcodes/shortcodes.php' ) ){

	require_once( dirname( __FILE__ ) .'/shortcodes/shortcodes.php' );	
}

if(file_exists( dirname( __FILE__ ) .'/inc/theme-support.php' ) ){

	require_once( dirname( __FILE__ ) .'/inc/theme-support.php' );	
}

if(file_exists( dirname( __FILE__ ) .'/inc/comments-helper.php' ) ){

	require_once( dirname( __FILE__ ) .'/inc/comments-helper.php' );	
}

if(file_exists( dirname( __FILE__ ) .'/lib/plugins/required-plugins.php' ) ){

	require_once( dirname( __FILE__ ) .'/lib/plugins/required-plugins.php' );	
}

//////////////////
register_activation_hook(__FILE__, 'flush_rewrite_reg');

function flush_rewrite_reg(){
	flush_rewrite_rules();
}

// Remove extra <p>tag
remove_filter( 'the_content', 'wpautop' );

// VC intigate with theme
add_action('vc_before_init', 'set_as_theme_vc');

function set_as_theme_vc(){
	vc_set_as_theme();
}


vc_map(array(
	'name'	=> 'Comet Slider',
	'base'	=> 'comet-slider'
));

