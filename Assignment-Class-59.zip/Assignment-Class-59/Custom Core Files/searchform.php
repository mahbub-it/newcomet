<form action="<?php echo home_url();  ?>" methode="GET" >
    <input type="text" placeholder="Search.." class="form-control">
</form>


