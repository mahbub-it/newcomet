<?php get_header(); ?>

    <section class="page-title parallax">
      <div data-parallax="scroll" data-image-src="<?php echo get_template_directory_uri(); ?>/images/bg/2.jpg" class="parallax-bg"></div>
      <div class="parallax-overlay">
        <div class="centrize">
          <div class="v-center">
            <div class="container">
              <div class="title center">
                <h1 class="upper"><?php global $newcomet; echo $newcomet['blog-title']; ?><span class="red-dot"></span></h1>
                <h4><?php global $newcomet; echo $newcomet['blog-subtitle']; ?></h4>
                <hr>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="container">
        <div class="col-md-9">
          <div class="blog-masonry two-col">

            <?php while(have_posts()) : the_post(); ?>

                <?php get_template_part('newcomet-post-formet/content', get_post_format()); ?>

            <?php endwhile; ?>

          </div>


        <!-- Start of pagination -->
          <?php 
          
          if (function_exists('the_posts_pagination')) {

            the_posts_pagination(array(
              'prev_text' => '<span aria-hidden="true"><i class="ti-arrow-left"></i></span>',
              'next_text' => '<span aria-hidden="true"><i class="ti-arrow-right"></i></span>',
              'screen_reader_text' => ' '
            ));

          }
          ?>
        </div>
        <!-- End of pagination -->

      <!-- Sidebar -->
      <?php get_sidebar(); ?>
      </div>
        </div>
      </div>

    </section>

<?php get_footer(); ?>