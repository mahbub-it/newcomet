<?php
// Slider Shortcode
add_shortcode('newcomet-slider', 'newcomet_home_slider');
function newcomet_home_slider(){
    ob_start(); ?>
    <section id="home">
      <div id="home-slider" class="flexslider">
        <ul class="slides">

        <?php 
        
        $slider = new WP_Query(array(
            'post_type'     => 'newcomet-slider',
            'post_per_page' => 3
        ));
        while($slider->have_posts()) : $slider->the_post();
        ?>
          <li><?php the_post_thumbnail(); ?>
            <div class="slide-wrap">
              <div class="slide-content">
                <div class="container">
                  <h1><?php the_title(); ?><span class="red-dot"></span></h1>
                  <h6><?php echo get_post_meta( get_the_id(), '_slider_subtitle', true ) ?></h6>
        <!-- ////Slider Section Button///// -->
        <p>
            <?php $left_button = get_post_meta(get_the_id(), '_button-left-text', true);
                      if(!empty($left_button)) : ?>
              <a href="<?php echo get_post_meta(get_the_id(), '_button-left-url', true) ?>" class="btn <?php if ( get_post_meta(get_the_id(), '_button-left-type', true) == 'transparent' ) {
                              echo 'btn-light-out';
                            }else {
                              echo 'btn-color btn-full';
                            } ?>">
                        <?php echo $left_button; ?>
                      </a>
                      <?php endif; ?>

                <?php $right_button = get_post_meta(get_the_id(), '_button-right-text', true);

                    if(!empty($right_button)) :
                  ?>

            <a href="<?php echo the_permalink(); ?>" class="btn <?php if ( get_post_meta(get_the_id(), '_button-right-type', true) == 'transparent' ) {
                  echo 'btn-light-out';
                  }else {
                  echo 'btn-color btn-full';
                } ?>">
                <?php echo $right_button; ?>
                </a>
        <?php endif; ?>

                  </p>
                </div>
              </div>
            </div>
          </li>

          <?php endwhile; ?>

        </ul>
      </div>
    </section>

    <?php return ob_get_clean();
}

// About Section Shotcode

add_shortcode('about-section', 'newcomet_about_section');

function newcomet_about_section($attr, $content = null){

  $attributes = extract(shortcode_atts(array(
    'title'   => 'Who We Are',
    'subtitle'  => 'We are driven by creative.',
    'content'   => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt sed ad possimus magnam maiores. Ipsam quas velit blanditiis debitis consequuntur mollitia assumenda nam obcaecati illo! Dolores deleniti animi.'
  ), $attr ));

  ob_start(); ?>

    <section id="about">
      <div class="container">
        <div class="title center">
          <h4 class="upper"><?php echo $subtitle; ?></h4>
          <h2><?php echo $title; ?><span class="red-dot"></span></h2>
          <hr>
        </div>
        <div class="section-content">
          <div class="col-md-8 col-md-offset-2">
            <p class="lead-text serif text-center"><?php echo do_shortcode($content); ?></p>
          </div>
        </div>
      </div>
    </section>

  <?php return ob_get_clean();

}

// Expertise Section Shortcode
add_shortcode('expertise-section', 'newcomet_expertise_section');

function newcomet_expertise_section($attr, $content = null){

  $attributes = extract(shortcode_atts(array(
    'title'             => 'New Expertise',
    'subtitle'          => 'THIS IS WHAT WE LOVE TO DO.',
    'bgimage'           => 'http://localhost/wordpress/wp-content/uploads/2023/07/3.jpg',
    'first_front_icon'  => 'focus',
    'first_back_icon'   => 'focus',
    'first_title'       => 'Branding',
    'first_content'     => 'Facilis doloribus illum quis, expedita mollitia voluptate non iure, perspiciatis repellat eveniet volup.',
    'second_front_icon'  => 'layers',
    'second_back_icon'   => 'layers',
    'second_title'       => 'Interactive',
    'second_content'     => 'Commodi totam esse quis alias, nihil voluptas repellat magni, id fuga perspiciatis, ut quia beatae, accus.',
    'third_front_icon'  => 'mobile',
    'third_back_icon'   => 'mobile',
    'third_title'       => 'Production',
    'third_content'     => 'Doloribus qui asperiores nisi placeat volup eum, nemo est, praesentium fuga alias sit quis atque accus.',
    'fourth_front_icon'  => 'globe',
    'fourth_back_icon'   => 'globe',
    'fourth_title'       => 'Editing',
    'fourth_content'     => 'Aliquid repellat facilis quis. Sequi excepturi quis dolorem eligendi deleniti fuga rerum itaque.'
  ), $attr ));

  ob_start(); ?>

<section class="p-0 b-0">
      <div class="col-md-6 col-sm-4 img-side img-left mb-0">
        <div class="img-holder"><img src="<?php echo $bgimage; ?>" alt="" class="bg-img">
          <div class="centrize">
            <div class="v-center">
              <div class="title txt-xs-center">
                <h4 class="upper"><?php echo $subtitle; ?></h4>
                <h3><?php echo $title; ?><span class="red-dot"></span></h3>
                <hr>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-md-offset-6 col-sm-8 col-sm-offset-4">
        <div class="row">
          <div class="services">
            <div class="col-sm-6 border-bottom border-right">
              <div class="service"><i class="icon-<?php echo $first_front_icon; ?>"></i><span class="back-icon"><i class="icon-<?php echo $first_back_icon; ?>"></i></span>
                <h4><?php echo $first_title; ?></h4>
                <hr>
                <p class="alt-paragraph"><?php echo $first_content; ?></p>
              </div>
            </div>
            <div class="col-sm-6 border-bottom">
              <div class="service"><i class="icon-<?php echo $second_front_icon; ?>"></i><span class="back-icon"><i class="icon-<?php echo $second_back_icon; ?>"></i></span>
                <h4><?php echo $second_title; ?></h4>
                <hr>
                <p class="alt-paragraph"><?php echo $second_content; ?></p>
              </div>
            </div>
            <div class="col-sm-6 border-bottom border-right">           
              <div class="service"><i class="icon-<?php echo $third_front_icon; ?>"></i><span class="back-icon"><i class="icon-<?php echo $third_back_icon; ?>"></i></span>
                <h4><?php echo $third_title; ?></h4>
                <hr>
                <p class="alt-paragraph"><?php echo $third_content; ?></p>
              </div>
            </div>
            <div class="col-sm-6 border-bottom border-right">           
              <div class="service"><i class="icon-<?php echo $fourth_front_icon; ?>"></i><span class="back-icon"><i class="icon-<?php echo $fourth_back_icon; ?>"></i></span>
                <h4><?php echo $fourth_title; ?></h4>
                <hr>
                <p class="alt-paragraph"><?php echo $fourth_content; ?></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

  <?php return ob_get_clean();
}

// Vision Section Shotcode
add_shortcode('vision-section', 'newcomet_vision_section');

  function newcomet_vision_section($attr, $content = null){

    $attributes = extract(shortcode_atts(array(
      'title'               => 'New The Vision',
      'subtitle'            => 'WHAT WE LOVE TO DO New.',
      'bgimage'             => 'http://localhost/wordpress/wp-content/uploads/2023/07/10.jpg',
      'small_title_one'     => 'One Title Strategy',
      'small_content_one'   => 'Natus totam adipisci illum aut nihil consequuntur ut, ducimus alias iusto facili.',
      'small_title_two'     => 'Two Title Strategy',
      'small_content_two'   => 'Two totam adipisci illum aut nihil consequuntur ut, ducimus alias iusto facili.',
      'small_title_three'   => 'Three Title Strategy',
      'small_content_three' => 'Three totam adipisci illum aut nihil consequuntur ut, ducimus alias iusto facili.',
      'small_title_four'    => 'Four Title Strategy',
      'small_content_four'  => 'Four totam adipisci illum aut nihil consequuntur ut, ducimus alias iusto facili.'

    ), $attr ));
  
    ob_start(); ?>
  <section>
      <div class="col-md-6 col-sm-4 img-side img-right">
        <div class="img-holder" style="background-image: url(&quot;<?php echo $bgimage; ?>&quot;);"></div>
      </div>
      <div class="container">
        <div class="col-md-5 col-sm-8">
          <div class="title">
            <h4 class="upper"><?php echo $subtitle; ?></h4>
            <h3><?php echo $title; ?><span class="red-dot"></span></h3>
            <hr>
          </div>
          <div class="col-md-6 col-sm-6">
            <div class="row">
              <div class="text-box">
                <h4 class="upper small-heading"><?php echo $small_title_one; ?></h4>
                <p><?php echo $small_content_one; ?></p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-sm-6">
            <div class="row">
              <div class="text-box">
                <h4 class="upper small-heading"><?php echo $small_title_two; ?></h4>
                <p><?php echo $small_content_two; ?></p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-sm-6">
            <div class="row">
              <div class="text-box">
                <h4 class="upper small-heading"><?php echo $small_title_three; ?></h4>
                <p><?php echo $small_content_three; ?></p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-sm-6">
            <div class="row">
              <div class="text-box">
                <h4 class="upper small-heading"><?php echo $small_title_four; ?></h4>
                <p><?php echo $small_content_four; ?></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

  <?php return ob_get_clean();

}


///////////// Portfolio Start ///////////////
  add_shortcode('newcomet-portfolio', 'newcomet_isotop_functionality');

  function newcomet_isotop_functionality($filterfunction, $filtercontents){

    $filter = extract(shortcode_atts(array(
      'title' => 'Selected Works'
    ), $filterfunction ));

  ob_start(); ?> 
  
  <section id="portfolio" class="pb-0">
      <div class="container">
        <div class="col-md-6">
          <div class="title m-0 txt-xs-center txt-sm-center">
            <h2 class="upper"><?php echo $title; ?><span class="red-dot"></span></h2>
            <hr>
          </div>
        </div>
        <div class="col-md-6">
          <ul id="filters" class="no-fix mt-25">
          <li data-filter="*" class="active">All</li>

          <?php 
          
            $terms = get_terms('newcomet-portfolio-category'); 

            foreach($terms as $term) :
            
          ?>        
            
            <li data-filter=".<?php echo $term->slug; ?>" class=""><?php echo $term->name; ?></li>

            <?php endforeach; ?>
          </ul>
        </div>
      </div>
      <div class="section-content pb-0">     
        <div id="works" class="four-col wide mt-50" style="position: relative; height: 952.5px;">

              <?php

              $portfolio = new WP_Query(array(
                'post_type'   => 'newcomet-portfolio'
              ));

              while($portfolio->have_posts()) : $portfolio->the_post(); 

              ?>

          <div style="position: absolute; left: 0px; top: 0px;" class="work-item  <?php
                        $terms = get_the_terms(get_the_id(), 'newcomet-portfolio-category');
                  
                          foreach($terms as $term){
                            echo $term->slug. " ";
                          }
                      ?>">
            <div class="work-detail"><a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?>
                <div class="work-info">
                  <div class="centrize">
                    <div class="v-center">
                      <h3><?php the_title(); ?></h3>
                      <p>  

                      <?php
                        $terms = get_the_terms(get_the_id(), 'newcomet-portfolio-category');
                  
                          foreach($terms as $term){
                            echo $term->name. " ";
                            // print_r($term);
                          }
                      ?>
                      
                      </p>
                    </div>
                  </div>
                </div></a></div>
          </div>

        <?php endwhile; ?>
          
        </div>
      </div>
    </section>
  
  
  <?php return ob_get_clean();

  }

  //////////////Our Client Section///////////////
  add_shortcode('newcomet-clients', 'newcomet_client_section');

  function newcomet_client_section($attr, $content = NULL){

    $attributes = extract(shortcode_atts(array(
      'title'             => 'Our Clients',
      'subtitle'          => 'SOME OF THE BEST.',
      'client_image_one'  => 'http://localhost/wordpress/wp-content/themes/newcomet/images/clients/1.png',
      'client_image_two'  => 'http://localhost/wordpress/wp-content/themes/newcomet/images/clients/2.png',
      'client_image_three'  => 'http://localhost/wordpress/wp-content/themes/newcomet/images/clients/3.png',
      'client_image_four'  => 'http://localhost/wordpress/wp-content/themes/newcomet/images/clients/4.png',
      'client_image_five'  => 'http://localhost/wordpress/wp-content/themes/newcomet/images/clients/5.png',
      'client_image_six'  => 'http://localhost/wordpress/wp-content/themes/newcomet/images/clients/6.png',
    ), $attr ));

  ob_start(); ?> 

  <section>
    <div class="container">
      <div class="title center">
        <h4 class="upper"><?php echo $subtitle; ?></h4>
        <h3><?php echo $title; ?><span class="red-dot"></span></h3>
        <hr>
      </div>
      <div class="section-content">
        <div class="boxes clients">
          <div class="col-sm-4 col-xs-6 border-right border-bottom"><img src="<?php echo $client_image_one; ?>" alt="" data-animated="true" class="client-image"></div>
          <div class="col-sm-4 col-xs-6 border-right border-bottom"><img src="<?php echo $client_image_two; ?>" alt="" data-animated="true" data-delay="500" class="client-image"></div>
          <div class="col-sm-4 col-xs-6 border-bottom"><img src="<?php echo $client_image_three; ?>" alt="" data-animated="true" data-delay="1000" class="client-image"></div>
          <div class="col-sm-4 col-xs-6 border-right"><img src="<?php echo $client_image_four; ?>" alt="" data-animated="true" class="client-image"></div>
          <div class="col-sm-4 col-xs-6 border-right"><img src="<?php echo $client_image_five; ?>" alt="" data-animated="true" data-delay="500" class="client-image"></div>
          <div class="col-sm-4 col-xs-6"><img src="<?php echo $client_image_six; ?>" alt="" data-animated="true" data-delay="1000" class="client-image"></div>
        </div>
      </div>
    </div>
  </section>

<?php return ob_get_clean(); 

  }

  ///// The Parallax Slider Section /////////
  add_shortcode('parallax-section', 'newcomet_parallax');

  function newcomet_parallax($attr, $content = NULL ){
    $attributes = extract(shortcode_atts(array(
      // 'parallax_bg_image' => 'http://localhost/wordpress/wp-content/themes/newcomet/images/bg/7.jpg',
      'title'    => 'What They Say New',
      'one_taxonomy'  => 'Dolorem natus, sint. Enim molestias expedita laboriosam perferendis possimus facere nostrum laudantium vero.',
      'one_author'    => 'Daenerys Targarien - Apple Inc.',
      'two_taxonomy'  => 'Texonomy Two Dolorem natus, sint. Enim molestias expedita laboriosam perferendis possimus facere nostrum laudantium vero.',
      'two_author'    => 'Author Two',
      'three_taxonomy'  => 'Texonomy Three',
      'three_author'    => 'Author Three',
      'four_taxonomy'  => 'Texonomy Four',
      'four_author'    => 'Author Four',
    ), $attr ));

    ob_start(); 
    ?>

<section class="parallax">
      <div data-parallax="scroll" data-image-src="images/bg/7.jpg" class="parallax-bg"></div>
      <div class="parallax-overlay pb-50 pt-50">
        <div class="container">
          <div class="title center">
            <h3><?php echo $title; ?><span class="red-dot"></span></h3>
            <hr>
          </div>
          <div class="section-content">
            <div id="testimonials-slider" data-options="{&quot;animation&quot;: &quot;slide&quot;, &quot;controlNav&quot;: true}" class="flexslider nav-outside">
              
            <div class="flex-viewport" style="overflow: hidden; position: relative;">
            <ul class="slides" style="width: 800%; transition-duration: 0s; transform: translate3d(-700px, 0px, 0px);">
            
            <li class="clone" aria-hidden="true" style="width: 700px; float: left; display: block;">

                  <blockquote>
                    <p>"<?php echo $one_taxonomy; ?>"</p>
                    <footer><?php echo $one_author; ?></footer>
                  </blockquote>

                </li>
                <li style="width: 700px; float: left; display: block;" class="flex-active-slide">
                  <blockquote>
                  <p>"<?php echo $two_taxonomy; ?>"</p>
                    <footer><?php echo $two_author; ?></footer>
                  </blockquote>
                </li>
                <li class="" style="width: 700px; float: left; display: block;">
                  <blockquote>
                  <p>"<?php echo $three_taxonomy; ?>"</p>
                    <footer><?php echo $three_author; ?></footer>
                  </blockquote>
                </li>
              <li style="width: 700px; float: left; display: block;" class="clone" aria-hidden="true">
                  <blockquote>
                  <p>"<?php echo $four_taxonomy; ?>"</p>
                    <footer><?php echo $four_author; ?></footer>
                  </blockquote>
                </li>
              </ul>
            </div>
            <ol class="flex-control-nav flex-control-paging"><li><a class="flex-active">1</a></li><li><a class="">2</a>
          </li></ol>
        </div>
             
          </div>
        </div>
      </div>

      </section>

<?php return ob_get_clean();
}

?>
<!-- Parallax Section End -->

<!-- /////////// The Blog Post Start ////////////// -->
<?php 

add_shortcode('homeblog-section', 'homeblog_section');

  function homeblog_section($attr, $content = NULL ){
    $attributes = extract(shortcode_atts(array(
    'title' => 'The Blog',
    'sub_title' => 'We have a few tips for you.',

  ), $attr ));
  
  ob_start(); 
 
  ?>
<section>
      <div class="container">
        <div class="title center">
          <h4 class="upper"><?php echo $sub_title; ?></h4>
          <h2><?php echo $title; ?><span class="red-dot"></span></h2>
          <hr>
        </div>
        <div class="section-content">
          <div class="col-md-8 col-md-offset-2">


          <?php 
        
        $homeblog = new WP_Query(array(
            'post_type'     => 'post',
            'posts_per_page' => 2
        ));
        while($homeblog->have_posts()) : $homeblog->the_post();
        ?>
          <div class="blog-post">
              <div class="post-body">
              <h3 class="serif"><a href="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
              <hr>
              <p class="serif"><?php the_content(); ?> [...]  </p>
              <div class="post-info upper"><a href="<?php the_permalink(); ?>">Read More</a><span class="pull-right black-text"><?php the_time('d F, Y') ?></span></div>
              </div>
          </div>
        <?php endwhile; ?>
          </div>
          <div class="clearfix"></div>
          <div class="mt-25">
            <p class="text-center"><a href="#" class="btn btn-color-out">View Full Blog          </a></p>
          </div>
        </div>
      </div>

      </section>

<?php return ob_get_clean();
}


